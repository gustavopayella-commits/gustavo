package com.mitv.app

object PlaylistParser {
    fun parse(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name = "Canal"
        var group = "General"
        var logo = ""
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(",", "Canal").trim().ifBlank { "Canal" }
                group = Regex("group-title=[\\\"']([^\\\"']+)[\\\"']", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1) ?: "General"
                logo = Regex("tvg-logo=[\\\"']([^\\\"']+)[\\\"']", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1) ?: ""
            } else if (line.isNotEmpty() && !line.startsWith("#") &&
                (line.startsWith("http://", true) || line.startsWith("https://", true))) {
                result += Channel(name, line, group, logo)
                name = "Canal"; group = "General"; logo = ""
            }
        }
        return result
    }
}
