package com.mitv.app
data class Channel(val name: String, val url: String, val group: String = "General", val logo: String = "")
