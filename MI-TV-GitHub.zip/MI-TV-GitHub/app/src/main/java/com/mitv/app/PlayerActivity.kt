package com.mitv.app

import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        val name = intent.getStringExtra("name") ?: "MI TV"
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        val title = TextView(this).apply {
            text = name; textSize = 16f; setTextColor(Color.WHITE)
            setBackgroundColor(0x99080D1B.toInt()); setPadding(18, 12, 18, 12)
        }
        root.addView(title, FrameLayout.LayoutParams(-1, -2))
        setContentView(root)
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            exo.playWhenReady = true
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    title.text = "Error de reproducción: ${error.errorCodeName}"
                }
            })
        }
    }
    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
