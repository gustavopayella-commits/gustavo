package com.mitv.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(8, 13, 27)
    private val panel = Color.rgb(17, 27, 49)
    private val blue = Color.rgb(22, 140, 255)
    private val violet = Color.rgb(155, 92, 255)
    private val prefs by lazy { getSharedPreferences("mitv", MODE_PRIVATE) }
    private val channels = mutableListOf<Channel>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var sourceInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
        val last = prefs.getString("last_source", null)
        if (!last.isNullOrBlank()) sourceInput.setText(last)
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "▣  MI TV"; textSize = 27f; setTextColor(Color.WHITE); setTypeface(null, 1)
        }
        val admin = Button(this).apply { text = "ADMIN"; setOnClickListener { adminLogin() } }
        header.addView(logo, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(admin)
        root.addView(header)
        root.addView(label("TU TELEVISIÓN, EN UN SOLO LUGAR", 12f, violet))
        root.addView(space(14))
        sourceInput = EditText(this).apply {
            hint = "URL de lista M3U / M3U8"
            setHintTextColor(0xFF9AA8C2.toInt()); setTextColor(Color.WHITE)
            setSingleLine(true); setPadding(14, 12, 14, 12); setBackgroundColor(panel)
        }
        root.addView(sourceInput, LinearLayout.LayoutParams(-1, 52))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(actionButton("CARGAR LISTA") { loadSource(sourceInput.text.toString().trim()) },
            LinearLayout.LayoutParams(0, 52, 1f))
        buttons.addView(actionButton("XTREAM") { xtreamDialog() },
            LinearLayout.LayoutParams(0, 52, 1f).apply { leftMargin = 8 })
        root.addView(space(8)); root.addView(buttons)
        status = label("Listo para cargar canales", 13f, 0xFFB8C5DC.toInt())
        root.addView(space(10)); root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("MI TV  •  Reproductor multimedia", 11f, 0xFF71809B.toInt()))
        setContentView(root)
        renderChannels()
    }

    private fun label(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); setPadding(2, 5, 2, 5)
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun actionButton(value: String, click: () -> Unit) = Button(this).apply {
        text = value; setTextColor(Color.WHITE); setBackgroundColor(blue); setOnClickListener { click() }
    }
    private fun field(hintValue: String, secret: Boolean = false) = EditText(this).apply {
        hint = hintValue; setTextColor(Color.WHITE); setHintTextColor(0xFF9AA8C2.toInt())
        if (secret) inputType = 129
    }

    private fun loadSource(source: String) {
        if (source.isBlank()) { toast("Ingresá una dirección M3U/M3U8"); return }
        prefs.edit().putString("last_source", source).apply()
        status.text = "Conectando y leyendo lista…"
        thread {
            try {
                val conn = (URL(source).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000; readTimeout = 20000
                    setRequestProperty("User-Agent", "MI-TV-Android/1.0")
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val parsed = PlaylistParser.parse(body)
                runOnUiThread {
                    channels.clear(); channels.addAll(parsed)
                    status.text = if (parsed.isEmpty()) "No se encontraron canales. Revisá la lista."
                    else "Se cargaron ${parsed.size} canales"
                    renderChannels()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "No se pudo cargar: ${e.message ?: "error de conexión"}" }
            }
        }
    }

    private fun xtreamDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 0) }
        val server = field("Servidor (https://servidor:puerto)")
        val user = field("Usuario")
        val pass = field("Contraseña", true)
        box.addView(server); box.addView(user); box.addView(pass)
        AlertDialog.Builder(this).setTitle("Conectar Xtream Codes").setView(box)
            .setPositiveButton("CONECTAR") { _, _ ->
                val base = server.text.toString().trim().trimEnd('/')
                val u = Uri.encode(user.text.toString().trim())
                val p = Uri.encode(pass.text.toString())
                if (base.isBlank() || u.isBlank() || p.isBlank()) toast("Completá servidor, usuario y contraseña")
                else {
                    prefs.edit().putString("xtream_server", base).putString("xtream_user", user.text.toString()).apply()
                    loadSource("$base/get.php?username=$u&password=$p&type=m3u_plus&output=ts")
                }
            }.setNegativeButton("CANCELAR", null).show()
    }

    private fun renderChannels() {
        list.removeAllViews()
        if (channels.isEmpty()) {
            list.addView(label("Tus canales aparecerán acá cuando cargues una lista.", 14f, 0xFF9AA8C2.toInt()))
            return
        }
        channels.forEach { channel ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(14, 10, 14, 10); setBackgroundColor(panel)
            }
            row.addView(TextView(this).apply {
                text = "▶  ${channel.name}"; textSize = 16f; setTextColor(Color.WHITE); setTypeface(null, 1)
            })
            row.addView(label(channel.group, 12f, violet))
            row.setOnClickListener {
                val url = channel.url
                if (url.contains("youtube.com", true) || url.contains("youtu.be", true)) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } else {
                    startActivity(Intent(this, PlayerActivity::class.java)
                        .putExtra("url", url).putExtra("name", channel.name))
                }
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
    }

    private fun adminLogin() {
        val existing = prefs.getString("admin_pin", null)
        if (existing == null) {
            val pin = field("Crear contraseña (mínimo 6 caracteres)", true)
            AlertDialog.Builder(this).setTitle("Configurar administrador")
                .setMessage("Creá una contraseña privada para este dispositivo.")
                .setView(pin).setPositiveButton("GUARDAR") { _, _ ->
                    val value = pin.text.toString()
                    if (value.length < 6) toast("Usá al menos 6 caracteres")
                    else { prefs.edit().putString("admin_pin", value).apply(); showAdmin() }
                }.setNegativeButton("CANCELAR", null).show()
        } else {
            val pin = field("Contraseña", true)
            AlertDialog.Builder(this).setTitle("Acceso administrador").setView(pin)
                .setPositiveButton("ENTRAR") { _, _ ->
                    if (pin.text.toString() == existing) showAdmin() else toast("Contraseña incorrecta")
                }.setNegativeButton("CANCELAR", null).show()
        }
    }

    private fun showAdmin() {
        val options = arrayOf("Agregar lista M3U / M3U8", "Configurar Xtream Codes", "Ver canales cargados", "Cerrar")
        AlertDialog.Builder(this).setTitle("MI TV • ADMINISTRACIÓN")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val input = field("https://sitio/lista.m3u")
                        AlertDialog.Builder(this).setTitle("Agregar lista").setView(input)
                            .setPositiveButton("GUARDAR") { _, _ ->
                                sourceInput.setText(input.text.toString())
                                loadSource(input.text.toString().trim())
                            }.setNegativeButton("CANCELAR", null).show()
                    }
                    1 -> xtreamDialog()
                    2 -> toast("Canales disponibles: ${channels.size}")
                }
            }.show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
